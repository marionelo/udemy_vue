<template>
  <div class="pokemon-layout">
      <h1>Pokemon Layout</h1>
      <router-view></router-view>
  </div>
</template>


<style scoped>
.pokemon-layout {
    background-color: deeppink;
}
</style>