<template>
    <h1>No Page Found</h1>
    <h3>404</h3>
</template>