<template>
    <div class="dragonball-layout">
        <h1>DBZ Layout</h1>
        <router-view></router-view>
    </div>
</template>


<style scoped>
.dragonball-layout {
    background-color: deepskyblue;
}
</style>
