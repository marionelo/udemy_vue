<template>
    <h3>About DBZ</h3>
</template>